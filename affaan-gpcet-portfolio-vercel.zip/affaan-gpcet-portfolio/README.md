# AFFAAN – GPCET CSE Portfolio

A responsive, multi-page academic and professional portfolio for A.S. Affaan Safi.

## Stack

- React + TypeScript
- Vite
- Tailwind CSS v4 integration
- React Router
- Lucide icons
- Static frontend, no backend required

## Local development

```bash
npm install
npm run dev
```

## Production build

```bash
npm run build
npm run preview
```

## Deploy to Vercel

1. Push this project to a GitHub repository.
2. In Vercel, choose **Add New → Project** and import that repository.
3. Let Vercel detect the Vite framework. Use build command `npm run build` and output directory `dist`.
4. Deploy. No environment variables are required for this static version.

The `vercel.json` rewrite sends application routes to `index.html`, so React Router can resolve paths such as `/research` and `/contact` on direct visits.

## Before public launch

- Confirm the public-facing CV PDF before adding a download button.
- Verify final DOI, page numbers, conference proceedings and indexing details before adding them to publication records.
- Confirm public-use permission for any additional certificate scans or personal photographs.
- The Unstop rank is labelled with the last-confirmed snapshot date and should be refreshed before launch if it has changed.

## Pages

Home, About, Professional Journey, Research Interests, Publications, Teaching & Academics, Achievements, Beyond Academia, Research Updates, Contact.

This is an individual portfolio. GPCET affiliation is stated as professional context; the site does not imply institutional ownership or endorsement.
