import { useState } from 'react';
import { NavLink, Route, Routes, Link, useLocation } from 'react-router-dom';
import {
  ArrowRight, ArrowUpRight, Atom, BookOpen, Check, Code2, ExternalLink,
  FileBadge, Github, GraduationCap, Layers3, Mail, Menu, Microscope, Network,
  Orbit, Sparkles, X, BadgeCheck, Laptop, Cpu, Globe2, BookMarked,
} from 'lucide-react';

const linkedin = 'https://www.linkedin.com/in/affaan-safi786/';
const github = 'https://github.com/AFFU-star';
const unstop = 'https://unstop.com/u/auliaaff4898';
const institution = 'https://www.gpcet.ac.in/';

const navItems = [
  ['About', '/about'], ['Journey', '/journey'], ['Research', '/research'],
  ['Publications', '/publications'], ['Teaching', '/teaching'],
  ['Achievements', '/achievements'], ['Beyond Academia', '/beyond'], ['Updates', '/updates'], ['Contact', '/contact'],
] as const;

function ScrollTop() {
  const location = useLocation();
  useEffect(() => { window.scrollTo({ top: 0, behavior: 'instant' as ScrollBehavior }); }, [location.pathname]);
  return null;
}

function Header() {
  const [open, setOpen] = useState(false);
  const location = useLocation();
  useEffect(() => setOpen(false), [location.pathname]);
  return <header className="site-header">
    <div className="header-inner shell">
      <Link to="/" className="brand" aria-label="Affaan home">
        <span className="brand-mark">AS<span>.</span></span>
        <span className="brand-copy"><strong>AFFAAN</strong><small>GPCET · CSE</small></span>
      </Link>
      <button className="menu-toggle" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen(v => !v)}>
        {open ? <X size={22}/> : <Menu size={22}/>}
      </button>
      <nav className={open ? 'main-nav open' : 'main-nav'} aria-label="Main navigation">
        {navItems.map(([label, path]) => <NavLink key={path} to={path} className={({isActive}) => isActive ? 'nav-link active' : 'nav-link'}>{label}</NavLink>)}
        <a className="nav-connect" href={linkedin} target="_blank" rel="noreferrer">Connect <ArrowUpRight size={14}/></a>
      </nav>
    </div>
  </header>;
}

function Footer() {
  return <footer className="site-footer">
    <div className="shell footer-top">
      <div><div className="footer-brand">AFFAAN<span>.</span></div><p>Where Education, Research, and Innovation Connect.</p></div>
      <div className="footer-links"><a href={linkedin} target="_blank" rel="noreferrer">LinkedIn <ArrowUpRight size={14}/></a><a href={github} target="_blank" rel="noreferrer">GitHub <ArrowUpRight size={14}/></a><a href={unstop} target="_blank" rel="noreferrer">Unstop <ArrowUpRight size={14}/></a></div>
    </div>
    <div className="shell footer-bottom"><span>© {new Date().getFullYear()} A.S. Affaan Safi</span><span>Independent academic & professional portfolio · GPCET affiliation</span></div>
  </footer>;
}

function PageIntro({eyebrow, title, intro}: {eyebrow: string; title: string; intro: string}) {
  return <section className="page-intro shell"><div className="eyebrow"><span className="eyebrow-line"/>{eyebrow}</div><h1>{title}</h1><p>{intro}</p></section>;
}

function SectionHeading({kicker, title, note}: {kicker: string; title: string; note?: string}) {
  return <div className="section-heading"><div><div className="eyebrow"><span className="eyebrow-line"/>{kicker}</div><h2>{title}</h2></div>{note && <p>{note}</p>}</div>;
}

function ArrowLink({to, children}: {to: string; children: ReactNode}) {
  return <Link className="arrow-link" to={to}>{children}<ArrowUpRight size={16}/></Link>;
}

function Home() {
  return <>
    <section className="hero shell">
      <div className="hero-content">
        <div className="eyebrow"><span className="eyebrow-line"/>ACADEMIA · RESEARCH · TECHNOLOGY</div>
        <h1>Ideas become<br/><em>understanding.</em><br/>Understanding becomes impact.</h1>
        <p className="hero-lede">I’m <strong>A.S. Affaan Safi</strong>, an Assistant Professor in Computer Science & Engineering at GPCET. My work connects computing education, applied research, and exploration of emerging technologies.</p>
        <div className="hero-actions"><Link className="button button-primary" to="/research">Explore my research <ArrowUpRight size={16}/></Link><a className="button button-quiet" href={linkedin} target="_blank" rel="noreferrer">Connect on LinkedIn <ArrowUpRight size={16}/></a></div>
        <div className="hero-meta"><span><span className="status-dot"/>Assistant Professor</span><span>GPCET · Kurnool, India</span></div>
      </div>
      <div className="hero-visual" aria-label="Academic and technical interests illustration">
        <div className="orbit orbit-one"/><div className="orbit orbit-two"/><div className="orbit orbit-three"/>
        <div className="orbit-core"><span>AS</span><small>COMPUTING<br/>IN CONTEXT</small></div>
        <div className="orbit-tag tag-ai"><Atom size={15}/> AI & ML</div><div className="orbit-tag tag-edge"><Network size={15}/> DISTRIBUTED</div><div className="orbit-tag tag-learn"><BookOpen size={15}/> EDUCATION</div><div className="orbit-tag tag-build"><Code2 size={15}/> SYSTEMS</div>
        <div className="visual-index">FIELD NOTES / 01</div>
      </div>
      <div className="hero-side-note">A curious mind. A practical lens. A research-led practice.</div>
    </section>

    <section className="signal-strip"><div className="shell signal-grid"><div><strong>01</strong><span>Teaching<br/>& Academics</span></div><div><strong>02</strong><span>Research<br/>& Publications</span></div><div><strong>03</strong><span>Professional<br/>Journey</span></div><div className="signal-quote">A connected view of education, research, and innovation.</div></div></section>

    <section className="section shell featured-section"><SectionHeading kicker="THE WORK" title="Three connected dimensions" note="A professional journey shaped by teaching, research, and hands-on technology exploration."/>
      <div className="feature-grid">
        <article className="feature-card feature-dark"><div className="card-top"><span>01 / TEACHING</span><GraduationCap size={22}/></div><h3>Learning that<br/><em>stays curious.</em></h3><p>Computer Science education, programming foundations, and laboratory learning at GPCET.</p><ArrowLink to="/teaching">Teaching & academics</ArrowLink></article>
        <article className="feature-card feature-paper"><div className="card-top"><span>02 / RESEARCH</span><Microscope size={22}/></div><h3>Questions worth<br/><em>investigating.</em></h3><p>Research contributions spanning computer vision, federated learning, and IoT cybersecurity.</p><ArrowLink to="/publications">Research contributions</ArrowLink></article>
        <article className="feature-card feature-sand"><div className="card-top"><span>03 / PRACTICE</span><Layers3 size={22}/></div><h3>Technology in<br/><em>motion.</em></h3><p>Professional experience, product thinking, and continuous exploration of emerging tools.</p><ArrowLink to="/journey">Professional journey</ArrowLink></article>
      </div>
    </section>

    <section className="section soft-band"><div className="shell split-band"><div><div className="eyebrow"><span className="eyebrow-line"/>CURRENT POSITION</div><h2>At the intersection of<br/><em>education and computing.</em></h2></div><div className="band-copy"><p>My work moves between the classroom, research questions, and the evolving software ecosystem. I’m interested in making technical ideas understandable, examining computational approaches, and learning how useful systems take shape.</p><ArrowLink to="/about">A little more about me</ArrowLink></div></div></section>

    <section className="section shell proof-section"><SectionHeading kicker="SELECTED MILESTONES" title="Work and service, in context"/><div className="proof-grid">
      <div className="proof-item"><div className="proof-icon"><FileBadge size={20}/></div><strong>IEEE ICAIHC 2026</strong><p>Reviewed five research-paper submissions across two conference tracks.</p><span className="proof-caption">RESEARCH SERVICE</span></div>
      <div className="proof-item"><div className="proof-icon"><Atom size={20}/></div><strong>C-DAC FDP · 2025</strong><p>Completed a certified five-day programme on Quantum Computing and HPC.</p><span className="proof-caption">FACULTY DEVELOPMENT</span></div>
      <div className="proof-item"><div className="proof-icon"><BookMarked size={20}/></div><strong>Research contributions</strong><p>Conference contributions at INCSTIC 2025 and CSNT 2026.</p><span className="proof-caption">SCHOLARLY WORK</span></div>
    </div></section>

    <section className="closing-cta"><div className="shell cta-inner"><div><div className="eyebrow"><span className="eyebrow-line"/>START A CONVERSATION</div><h2>Good ideas grow<br/><em>through exchange.</em></h2></div><div className="cta-right"><p>For academic conversations, research exchange, or professional connections, LinkedIn is the best place to reach me.</p><a className="button button-light" href={linkedin} target="_blank" rel="noreferrer">Connect on LinkedIn <ArrowUpRight size={16}/></a></div></div></section>
  </>;
}

function About() {
  return <><PageIntro eyebrow="ABOUT" title={<>A professional practice<br/><em>built around curiosity.</em></>} intro="Computer Science education, applied research, and the exploration of technologies that are changing how we build and understand systems."/>
    <section className="section shell about-layout"><div className="about-stamp"><div className="stamp-ring">COMPUTER SCIENCE · RESEARCH · EDUCATION ·</div><div className="stamp-center">AS<span>.</span><small>GPCET<br/>CSE</small></div></div><div className="about-copy"><p className="large-copy">I am an Assistant Professor in the Department of Computer Science and Engineering at G. Pullaiah College of Engineering and Technology.</p><p>My professional interests span computer science education, applied artificial intelligence, intelligent computing, and software development. I am particularly interested in exploring how emerging computational approaches can be applied to practical problems across different domains.</p><p>My academic background includes undergraduate and postgraduate study in Computer Science and Engineering at GPCET. My research work has explored Computer Vision, Deep Learning, Federated Learning, Quantum-Inspired Computing, and IoT Cybersecurity.</p><p>Alongside teaching and research, I continue to explore emerging AI technologies, software development practices, AI-enabled products, and the relationship between technical engineering and product thinking.</p></div></section>
    <section className="section soft-band"><div className="shell"><SectionHeading kicker="ACADEMIC BACKGROUND" title="A foundation in computing"/><div className="education-grid"><div className="education-card"><span>POSTGRADUATE</span><GraduationCap size={23}/><h3>Master of Technology</h3><p>Computer Science and Engineering</p><strong>GPCET · 8.20 CGPA</strong></div><div className="education-card"><span>UNDERGRADUATE</span><GraduationCap size={23}/><h3>Bachelor of Technology</h3><p>Computer Science and Engineering</p><strong>GPCET · 7.98 CGPA</strong></div></div></div></section>
  </>;
}

const timeline = [
  {date:'JUNE 2026 — PRESENT', role:'AI Intern – UX/UI', org:'FlyRank AI', type:'INDUSTRY EXPERIENCE', body:'An ongoing learning journey at the intersection of Artificial Intelligence and User Experience / User Interface design.', bullets:['UX/UI fundamentals and user-centred design','AI product design and user experience','Wireframing, prototyping, and interface development','AI search, organic growth, and emerging AI-powered platforms','Connecting AI engineering with product design'], note:'Current focus areas; no completed product deliverables are claimed.'},
  {date:'JUNE 2024 — FEBRUARY 2025', role:'Java Full Stack Development Trainee', org:'Microcare Academy', type:'STRUCTURED TRAINING', body:'Structured training combining conceptual learning, coding exercises, and practical implementations.', bullets:['Java programming and object-oriented programming','HTML, CSS, and JavaScript','SQL, MySQL, and Oracle databases','Backend Java application development','Git and GitHub for version control']},
  {date:'JUNE — AUGUST 2023', role:'Web Development Intern', org:'PHN Technology Pvt. Ltd. · Pune', type:'INTERNSHIP · 2 MONTHS', body:'A two-month web development internship associated with G. Pullaiah College of Engineering and Technology.', bullets:['PHP','HTML and CSS','JavaScript','React'], note:'Internship description focuses on professional exposure, adaptability, and willingness to learn.'},
];

function Journey() {
  return <><PageIntro eyebrow="PROFESSIONAL JOURNEY" title={<>Learning, practice,<br/><em>and applied work.</em></>} intro="A growing professional path across academic teaching, structured technical training, and industry exposure."/>
    <section className="section shell"><div className="current-role"><div className="current-role-icon"><GraduationCap size={25}/></div><div><span className="proof-caption">CURRENT ROLE</span><h2>Assistant Professor</h2><p>Department of Computer Science and Engineering · G. Pullaiah College of Engineering and Technology</p><div className="tag-row"><span>Teaching</span><span>Laboratory instruction</span><span>Academic coordination</span></div></div><span className="current-indicator"><i/> CURRENT</span></div>
      <div className="timeline">{timeline.map((item,i)=><article className="timeline-item" key={item.role}><div className="timeline-marker"><span>0{i+1}</span></div><div className="timeline-content"><div className="timeline-meta"><span>{item.type}</span><time>{item.date}</time></div><h2>{item.role}</h2><h3>{item.org}</h3><p>{item.body}</p><ul className="check-list">{item.bullets.map(b=><li key={b}><Check size={15}/>{b}</li>)}</ul>{item.note && <p className="small-note">{item.note}</p>}</div></article>)}</div>
    </section>
  </>;
}

const researchAreas = [
  {icon:<Orbit size={22}/>, title:'Computer Vision & Intelligent Systems', points:['Human Activity Recognition','Video-based activity analysis','Deep Learning architectures','Anomaly Detection']},
  {icon:<Network size={22}/>, title:'Federated Learning & Distributed Intelligence', points:['Federated Learning frameworks','Privacy-aware distributed learning','Quantum-Inspired Computing','Distributed intelligence approaches']},
  {icon:<Cpu size={22}/>, title:'IoT Cybersecurity & Edge Computing', points:['IoT security','Privacy-preserving computational approaches','Edge-oriented intelligent systems','Distributed computing']},
  {icon:<Atom size={22}/>, title:'Emerging Computational Approaches', points:['Intelligent healthcare systems','Quantum Computing','High-Performance Computing','AI and Machine Learning applications']},
];
function Research() {
  return <><PageIntro eyebrow="RESEARCH INTERESTS" title={<>Questions at the edge<br/><em>of intelligent systems.</em></>} intro="My research interests focus on computational approaches to intelligent systems, distributed learning, and applied artificial intelligence."/>
    <section className="section shell"><div className="research-grid">{researchAreas.map((a,i)=><article className="research-card" key={a.title}><div className="research-card-top"><div className="research-icon">{a.icon}</div><span>AREA 0{i+1}</span></div><h2>{a.title}</h2><ul>{a.points.map(p=><li key={p}>{p}</li>)}</ul></article>)}</div></section>
    <section className="section soft-band"><div className="shell research-note"><div className="eyebrow"><span className="eyebrow-line"/>RESEARCH LENS</div><p className="large-copy">From intelligent perception to distributed learning, I’m interested in how computational methods can be shaped around the constraints and needs of real systems.</p><ArrowLink to="/publications">Explore selected research contributions</ArrowLink></div></section>
  </>;
}

function Publications() {
  return <><PageIntro eyebrow="RESEARCH PUBLICATIONS" title={<>Research shaped by<br/><em>real-world questions.</em></>} intro="Selected conference research contributions, organized by research domain. Publication metadata is kept conservative and will be expanded as final proceedings records are confirmed."/>
    <section className="section shell"><div className="publication-list">
      <article className="publication-card"><div className="publication-number">01</div><div className="publication-main"><div className="eyebrow"><span className="eyebrow-line"/>COMPUTER VISION · DEEP LEARNING</div><h2>A Hybrid YOLOv8-GRU Framework for Real-Time Human Activity Recognition and Anomaly Detection in ATM Centers</h2><p>Research on combining visual recognition with temporal modelling for activity recognition and anomaly detection in ATM environments.</p><div className="publication-meta"><span>Major M.Tech project</span><span>CSNT 2026</span><span>Co-author: Kuppala Laxmi</span></div></div><div className="publication-mark"><Microscope size={26}/></div></article>
      <article className="publication-card"><div className="publication-number">02</div><div className="publication-main"><div className="eyebrow"><span className="eyebrow-line"/>FEDERATED LEARNING · IoT SECURITY</div><h2>Quantum Inspired Federated Learning Framework for Real Time IoT Cybersecurity</h2><p>Research exploring a quantum-inspired federated learning approach in the context of IoT cybersecurity.</p><div className="publication-meta"><span>Minor M.Tech project</span><span>INCSTIC 2025 · Geeta University</span></div><div className="proceedings-note"><BookOpen size={16}/><span><strong>Proceedings:</strong> <em>Smart Technologies and Intelligent Computing</em>, CRC Press / Routledge. ISBN 9781041128533.</span></div></div><div className="publication-mark"><Network size={26}/></div></article>
    </div></section>
    <section className="section soft-band"><div className="shell"><SectionHeading kicker="CONFERENCE CONTRIBUTIONS" title="Scholarly engagement"/><div className="conference-row"><div><strong>INCSTIC 2025</strong><span>International Conference on Smart Technologies and Intelligent Computing · Geeta University</span></div><span className="conference-year">2025</span></div><div className="conference-row"><div><strong>CSNT 2026</strong><span>Conference research contribution associated with the major project</span></div><span className="conference-year">2026</span></div><p className="small-note bottom-note">DOI, page numbers, and indexing details will be added after matching them against the final proceedings records. No unverified indexing claims are made here.</p></div></section>
  </>;
}

const skillGroups = [
  ['Programming',['C','Python','Java','JavaScript']],
  ['Web technologies',['HTML','CSS','React','Tailwind CSS']],
  ['Databases',['MySQL','Oracle']],
  ['AI / ML libraries',['scikit-learn','TensorFlow','PyTorch','Pandas']],
  ['Development tools',['Git','GitHub','Visual Studio Code','Google Colab']],
  ['AI & technical exploration',['Google AI Studio','NotebookLM','AI coding assistants']],
  ['Research & knowledge-work tools',['Miro','GitBook','Notion']],
];
function Teaching() {
  return <><PageIntro eyebrow="TEACHING & ACADEMICS" title={<>Teaching computing<br/><em>with a practical lens.</em></>} intro="Academic teaching and laboratory responsibilities in Computer Science and Engineering at GPCET."/>
    <section className="section shell"><div className="teaching-layout"><div className="teaching-main"><div className="eyebrow"><span className="eyebrow-line"/>CURRENT TEACHING</div><div className="course-row"><span className="course-index">01</span><div><h2>Object-Oriented Programming with Java</h2><p>OOPJ · Theory and programming concepts</p></div><Code2 size={22}/></div><div className="course-row"><span className="course-index">02</span><div><h2>ADSA Laboratory</h2><p>Programming and practical laboratory work</p></div><Laptop size={22}/></div><div className="teaching-subjects"><div className="eyebrow"><span className="eyebrow-line"/>TECHNICAL TEACHING AREAS</div><div className="tag-row large-tags"><span>Programming fundamentals: C, Python, Java</span><span>Artificial Intelligence & Machine Learning</span><span>Database Management Systems</span><span>Web & Full-Stack Development</span></div></div></div><aside className="teaching-aside"><div className="aside-symbol"><BookOpen size={28}/></div><span className="proof-caption">ACADEMIC ROLE</span><h3>Computer Science<br/><em>& Engineering</em></h3><p>Teaching, laboratory instruction, and departmental academic responsibilities.</p><a href={institution} target="_blank" rel="noreferrer">GPCET institutional website <ExternalLink size={14}/></a></aside></div></section>
    <section className="section soft-band"><div className="shell"><SectionHeading kicker="TECHNICAL TOOLKIT" title="Technologies and tools" note="A working toolkit across programming, web development, AI/ML, and technical exploration. Listed tools are not intended as a claim of expert-level proficiency in every item."/><div className="skills-grid">{skillGroups.map(([name,skills])=><div className="skill-group" key={name as string}><h3>{name as string}</h3><div className="skill-pills">{(skills as string[]).map(s=><span key={s}>{s}</span>)}</div></div>)}</div></div></section>
  </>;
}

function Achievements() {
  return <><PageIntro eyebrow="ACHIEVEMENTS & RECOGNITION" title={<>Contributions, service,<br/><em>and continued learning.</em></>} intro="A curated record of verified research service, professional development, academic recognition, and selected credentials."/>
    <section className="section shell"><div className="ranking-card"><div><span className="proof-caption">UNSTOP PLATFORM RECOGNITION · LAST CONFIRMED 30 OCT 2026</span><h2>Top 1% <em>on Unstop.</em></h2><p>Platform ranking snapshot recorded from the profile details shared during portfolio preparation.</p><a className="ranking-link" href={unstop} target="_blank" rel="noreferrer">View Unstop profile <ArrowUpRight size={15}/></a></div><div className="rank-stats"><div><strong>3,609</strong><span>GLOBAL RANK</span></div><div><strong>122,923</strong><span>POINTS</span></div></div></div>
      <div className="achievement-grid"><article className="achievement-card"><div className="achievement-icon"><BadgeCheck size={22}/></div><span className="proof-caption">RESEARCH & ACADEMIC SERVICE · 2026</span><h3>IEEE ICAIHC 2026 Conference Reviewer</h3><p>Reviewed five assigned research-paper submissions across Intelligent Computation in Healthcare and IoMT & Edge Computing for Healthcare.</p><div className="certificate-preview"><img src="/images/icaihc-2026-reviewer-certificate.png" alt="ICAIHC 2026 Certificate of Appreciation recognizing reviewer service"/><a href="/images/icaihc-2026-reviewer-certificate.png" target="_blank" rel="noreferrer">View reviewer certificate <ArrowUpRight size={14}/></a></div></article>
      <article className="achievement-card"><div className="achievement-icon"><Atom size={22}/></div><span className="proof-caption">FACULTY DEVELOPMENT · SEPTEMBER 2025</span><h3>National-Level FDP: Quantum Computing & HPC</h3><p>Completed and certified a five-day Faculty Development Programme led by C-DAC Pune in collaboration with GPCET, RCEW Kurnool, and RMJIT Solutions.</p><div className="achievement-meta"><span>22–26 September 2025</span><span>5 days</span></div></article>
      <article className="achievement-card"><div className="achievement-icon"><FileBadge size={22}/></div><span className="proof-caption">TECHNICAL CERTIFICATION · FEBRUARY 2022</span><h3>Python Programming Certification</h3><p>Issued by Infotech Computer Center, Bhagya Nagar, Kurnool.</p><div className="achievement-meta"><span>Credential ID: IT PY290422AFM801P</span></div></article>
      <article className="achievement-card"><div className="achievement-icon"><BookMarked size={22}/></div><span className="proof-caption">RESEARCH WEBINAR · JUNE 2025</span><h3>Structuring and Executing High-Impact Literature Reviews</h3><p>SciSpace webinar participation covering research scoping, literature review structure, synthesis strategies, and ethical use of AI in academic research.</p><div className="achievement-meta"><span>SciSpace</span><span>June 2025</span></div></article></div>
    </section>
  </>;
}

function Beyond() {
  const items = [
    {icon:<Sparkles size={22}/>, title:'Emerging AI & technology', text:'Exploring new AI tools, AI-enabled workflows, agentic systems, and emerging computational technologies.'},
    {icon:<Globe2 size={22}/>, title:'Software development', text:'Following modern web technologies, full-stack engineering practices, developer ecosystems, and software products.'},
    {icon:<Layers3 size={22}/>, title:'Product thinking', text:'Exploring how technical capabilities translate into useful products through user experience, product strategy, and problem-oriented design.'},
    {icon:<Microscope size={22}/>, title:'Research & experimentation', text:'Learning through technical exploration, documentation, experimentation, and the evaluation of new tools and development approaches.'},
  ];
  return <><PageIntro eyebrow="BEYOND ACADEMIA" title={<>Curiosity beyond<br/><em>the syllabus.</em></>} intro="The technology landscape keeps moving. I enjoy following its edges, understanding what is changing, and exploring where new capabilities might become useful."/>
    <section className="section shell"><div className="beyond-grid">{items.map((x,i)=><article className="beyond-card" key={x.title}><span className="beyond-number">0{i+1}</span><div className="beyond-icon">{x.icon}</div><h2>{x.title}</h2><p>{x.text}</p></article>)}</div></section>
    <section className="section soft-band"><div className="shell closing-thought"><div className="eyebrow"><span className="eyebrow-line"/>A CONTINUOUS PRACTICE</div><p className="large-copy">Stay curious. Understand the mechanism. Experiment with intent. Build with context.</p></div></section>
  </>;
}

function Updates() {
  const updates = [
    ['SEPTEMBER 2026','IEEE ICAIHC 2026','Completed research-paper reviewing for five assigned submissions across two healthcare computing tracks.'],
    ['2026','CSNT 2026','Conference research contribution associated with the major M.Tech project on human activity recognition and anomaly detection.'],
    ['2025','INCSTIC 2025','Research contribution on a quantum-inspired federated learning framework for IoT cybersecurity.'],
    ['SEPTEMBER 2025','C-DAC Quantum Computing & HPC FDP','Completed a certified five-day national-level Faculty Development Programme.'],
  ];
  return <><PageIntro eyebrow="RESEARCH UPDATES" title={<>Selected milestones,<br/><em>not a running feed.</em></>} intro="A concise record of completed research, scholarly service, and professional-development milestones."/><section className="section shell"><div className="updates-list">{updates.map(([date,title,desc],i)=><article className="update-row" key={title}><span className="update-index">0{i+1}</span><time>{date}</time><div><h2>{title}</h2><p>{desc}</p></div><ArrowUpRight size={18}/></article>)}</div></section></>;
}

function Contact() {
  return <><PageIntro eyebrow="CONTACT" title={<>Open to thoughtful<br/><em>professional exchange.</em></>} intro="For academic conversations, research exchange, collaboration, or professional connections, please use one of the channels below."/>
    <section className="section shell contact-layout"><div className="contact-primary"><span className="proof-caption">PRIMARY CONTACT</span><h2>Let’s connect<br/><em>on LinkedIn.</em></h2><p>LinkedIn is the preferred channel for professional communication and networking.</p><a className="button button-primary" href={linkedin} target="_blank" rel="noreferrer">Open LinkedIn profile <ArrowUpRight size={16}/></a></div><div className="contact-details"><a className="contact-line" href="mailto:affaansafi786@gmail.com"><span><Mail size={19}/></span><div><small>PROFESSIONAL EMAIL</small><strong>affaansafi786@gmail.com</strong></div><ArrowUpRight size={16}/></a><a className="contact-line" href="mailto:20at1a0503@gpcet.ac.in"><span><Mail size={19}/></span><div><small>INSTITUTIONAL EMAIL</small><strong>20at1a0503@gpcet.ac.in</strong></div><ArrowUpRight size={16}/></a><a className="contact-line" href={github} target="_blank" rel="noreferrer"><span><Github size={19}/></span><div><small>CODE & PUBLIC REPOSITORIES</small><strong>github.com/AFFU-star</strong></div><ArrowUpRight size={16}/></a><a className="contact-line" href={institution} target="_blank" rel="noreferrer"><span><GraduationCap size={19}/></span><div><small>INSTITUTIONAL AFFILIATION</small><strong>G. Pullaiah College of Engineering and Technology</strong></div><ArrowUpRight size={16}/></a></div></section>
    <section className="section soft-band"><div className="shell contact-note"><span className="eyebrow"><span className="eyebrow-line"/>PORTFOLIO NOTE</span><p>This is an individual academic and professional portfolio. The GPCET affiliation identifies my professional association; this website is not the official institutional website of GPCET.</p></div></section>
  </>;
}

function NotFound() { return <div className="shell not-found"><span className="eyebrow">404 / PAGE NOT FOUND</span><h1>This page is<br/><em>still unwritten.</em></h1><Link className="button button-primary" to="/">Return home <ArrowRight size={16}/></Link></div>; }

export default function App() {
  return <><ScrollTop/><Header/><main><Routes>
    <Route path="/" element={<Home/>}/><Route path="/about" element={<About/>}/><Route path="/journey" element={<Journey/>}/><Route path="/research" element={<Research/>}/><Route path="/publications" element={<Publications/>}/><Route path="/teaching" element={<Teaching/>}/><Route path="/achievements" element={<Achievements/>}/><Route path="/beyond" element={<Beyond/>}/><Route path="/updates" element={<Updates/>}/><Route path="/contact" element={<Contact/>}/><Route path="*" element={<NotFound/>}/>
  </Routes></main><Footer/></>;
}
